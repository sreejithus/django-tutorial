from django.db import models
from django.contrib.auth.models import User
# Create your models here.


class Task(models.Model):
            user = models.ForeignKey(User,on_delete=models.CASCADE)
            title = models.CharField(max_length=100)
            description  =  models.TextField(max_length=500)
            created  = models.DateField(auto_now_add=True)
            completed = models.BooleanField(default=False)