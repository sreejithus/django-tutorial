"""
URL configuration for Library_Api project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from Library import views
from rest_framework.authtoken.views import obtain_auth_token
urlpatterns = [
    path('admin/', admin.site.urls),
    path('booklist',views.ListCreate.as_view()),
    path('booklist/<int:id>',views.RetrieveUpdateDelete.as_view()),
    path('register',views.RegisterUser.as_view()),
    path('login',obtain_auth_token),
    path('logout',views.Logout.as_view()),
    path('searchbook',views.SearchItem.as_view())
]

# 28f6ce65674d774cddf4b288b8851219eb6d3498