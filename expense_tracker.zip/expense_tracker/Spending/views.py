from django.shortcuts import render

# Create your views here.
from rest_framework.response import Response
from rest_framework import status

from .serializers import Userserializer
from rest_framework.views import APIView
from django.contrib.auth.models import User
from django.shortcuts import get_object_or_404
from rest_framework.permissions import IsAuthenticated
class Register_user(APIView):
            def post(self,request):
                           serializer_instance = Userserializer(data=request.data)
                           if serializer_instance.is_valid():
                                       serializer_instance.save()
                                       return Response(serializer_instance.data,status=status.HTTP_201_CREATED)
                           else:
                                   Response(serializer_instance.errors,status=status.HTTP_400_BAD_REQUEST)



class Current_Loggedin(APIView):
                permission_classes= [IsAuthenticated]
                def get(self,request):
                        
                            u = request.user
                            serializer_instance  = Userserializer(u)
        
                            return Response(serializer_instance.data,status=status.HTTP_200_OK)