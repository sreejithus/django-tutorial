from rest_framework import serializers


from django.contrib.auth.models import User
class Userserializer(serializers.ModelSerializer):
             class Meta:
                      model= User
                      fields = ['first_name','last_name','username','password','email'] 
             def create(self, validated_data):
                     return User.objects.create_user(**validated_data)


